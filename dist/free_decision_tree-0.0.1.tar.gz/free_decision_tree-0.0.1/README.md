# Download

```
pip install git+https://github.com/IanAguiar-ai/free_decision_tree
```
