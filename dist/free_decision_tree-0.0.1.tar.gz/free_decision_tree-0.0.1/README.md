# DecisionTree

## Download

```
pip install git+https://github.com/IanAguiar-ai/free_decision_tree
```

## Inputs

...

## Use

### Example

...

### Prediction

...

### Plot tree

...

### Modifiable parts

- Individual losses (```loss_function```)

...

- Merging of losses (```loss_calc```)

...

## Estructure

...
